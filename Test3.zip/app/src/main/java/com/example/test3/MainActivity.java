package com.example.test3;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView mListView = null;
    BaseAdapterEx mAdapter = null;
    ArrayList<Recipe> mData = null;
    RecipeDbHelper mDbHelper = null;

    EditText mSearchEditText = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 레시피 데이터베이스에서 데이터를 불러와 mData에 설정
        mDbHelper = new RecipeDbHelper(this);
        SQLiteDatabase db = mDbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM recipes", null);

        mData = new ArrayList<Recipe>();
        while (cursor.moveToNext()) {
            Recipe recipe = new Recipe();
            //recipe.setId(cursor.getInt(cursor.getColumnIndexOrThrow("id")));
            recipe.setTitle(cursor.getString(cursor.getColumnIndexOrThrow("title")));
            recipe.setLink(cursor.getString(cursor.getColumnIndexOrThrow("link")));
            //recipe.setIngredient(cursor.getString(cursor.getColumnIndexOrThrow("ingredient")));
            mData.add(recipe);
        }
        cursor.close();
        mDbHelper.close();

        // 어댑터 생성 및 mData 설정
        mAdapter = new BaseAdapterEx(this, mData);

        // 리스트뷰에 어댑터 설정
        mListView = findViewById(R.id.list_view);
        mListView.setAdapter(mAdapter);

        // EditText 초기화 및 이벤트 리스너 등록
        mSearchEditText = findViewById(R.id.search_text);
        mSearchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mAdapter.getFilter().filter(s);
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }
}
