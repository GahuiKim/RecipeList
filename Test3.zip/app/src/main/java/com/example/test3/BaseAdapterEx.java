package com.example.test3;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.example.test3.Recipe;

import java.util.ArrayList;

public class BaseAdapterEx extends BaseAdapter implements Filterable {
    private Context mContext;
    private ArrayList<Recipe> mData;
    private ArrayList<Recipe> filteredData;
    private LayoutInflater mLayoutInflater;

    public BaseAdapterEx(Context context, ArrayList<Recipe> data) {
        mContext = context;
        mData = data;
        filteredData = data;
        mLayoutInflater = LayoutInflater.from(mContext);
    }

    @Override
    public int getCount() {
        return filteredData.size();
    }

    @Override
    public Object getItem(int position) {
        return filteredData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView == null) {
            convertView = mLayoutInflater.inflate(R.layout.list_view_item_layout, null);

            viewHolder = new ViewHolder();
            viewHolder.titleTextView = convertView.findViewById(R.id.title_text);
            //viewHolder.ingredientTextView = convertView.findViewById(R.id.ingredient_text);

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        Recipe recipe = filteredData.get(position);

        //viewHolder.idTextView.setText(String.valueOf(recipe.getId()));
        viewHolder.titleTextView.setText(recipe.getTitle());
        //viewHolder.ingredientTextView.setText(recipe.getIngredient());

        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(recipe.getLink()));
                mContext.startActivity(intent);
            }
        });

        return convertView;
    }

    @Override
    public Filter getFilter() {
        Filter filter = new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                FilterResults filterResults = new FilterResults();

                if (constraint == null || constraint.length() == 0) {
                    filterResults.count = mData.size();
                    filterResults.values = mData;
                } else {
                    String searchString = constraint.toString().toLowerCase();
                    ArrayList<Recipe> filteredList = new ArrayList<>();
                    for (Recipe recipe : mData) {
                        if (recipe.getTitle().toLowerCase().contains(searchString) ) { //|| recipe.getIngredient().toLowerCase().contains(searchString)
                            filteredList.add(recipe);
                        }
                    }
                    filterResults.count = filteredList.size();
                    filterResults.values = filteredList;
                }

                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                filteredData = (ArrayList<Recipe>) results.values;
                notifyDataSetChanged();
            }
        };

        return filter;
    }

    private static class ViewHolder {
        //TextView idTextView;
        TextView titleTextView;
        //TextView ingredientTextView;
    }
}
