package com.example.test3;

public class RecipeList
{
    String mTitle = ""; //제목
    //String mIngredient = ""; //재료
    String mLink = ""; //링크
}
