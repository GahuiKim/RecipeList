package com.example.test3;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class RecipeDbHelper extends SQLiteOpenHelper {
    private static final String TAG = "RecipeDbHelper";

    private static final String DB_NAME = "recipes.db";
    private static final int DB_VERSION = 1;
    private static final String DB_PATH = "/data/data/com.example.test3/databases/";

    private final Context mContext;

    public RecipeDbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        this.mContext = context;
        createDatabase();
    }

    private void createDatabase() {
        boolean dbExist = checkDatabase();

        if (!dbExist) {
            getReadableDatabase();

            try {
                copyDatabase();
            } catch (IOException e) {
                Log.e(TAG, "Error copying database");
                throw new RuntimeException("Error copying database");
            }
        }
    }

    private boolean checkDatabase() {
        String path = DB_PATH + DB_NAME;
        File file = new File(path);

        return file.exists();
    }

    private void copyDatabase() throws IOException {
        InputStream inputStream = mContext.getAssets().open(DB_NAME);
        String outFileName = DB_PATH + DB_NAME;
        OutputStream outputStream = new FileOutputStream(outFileName);

        byte[] buffer = new byte[1024];
        int length;
        while ((length = inputStream.read(buffer)) > 0) {
            outputStream.write(buffer, 0, length);
        }

        outputStream.flush();
        outputStream.close();
        inputStream.close();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // 이 클래스에서는 사용하지 않으므로 구현하지 않는다.
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // 이 클래스에서는 사용하지 않으므로 구현하지 않는다.
    }
}
